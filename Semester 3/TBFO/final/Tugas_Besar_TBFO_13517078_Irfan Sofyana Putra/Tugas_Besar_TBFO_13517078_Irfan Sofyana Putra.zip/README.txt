Folder ini terdiri dari beberapa file, yaitu:

1. FileStates
   FileStates adalah sebuah file berisi data mengenai DFA yang digunakan. Seperti 
   daftar states, final states, start states, daftar simbol dan transition table

2. Laporan Tugas Besar TBFO
   File ini adalah laporan dari tubes pertama mata kuliah TBFO yaitu permainan tic-tac-     toe dengan finite automata

3. tictactoe.c
   file ini adalah kode program dari permainan tic-tac-toe yang dibuat

4. tictactoe.exe
   Ini adalah aplikasi untuk mencoba permainan tic-tac-toe. Sangat disarankan untuk    menggunakannya dengan sistem operasi windows.

Selamat Bermain!